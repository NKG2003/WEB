const langArr = {
    "company" :  {
        "ru": "Компания",
        "en": "Company",
        "kz": "Компания",
    }, 
    "history": {
        "ru": "объем памяти",
        "en": "History",
        "kz": "Тарих",
    }, 
    "organizational-structure": {
        "ru": "Организационная структура",
        "en": "Organizational structure",
        "kz": "Ұйымдық құрылым",
    }, 
    "leadership": {
        "ru": "Руководство",
        "en": "leadership",
        "kz": "Руководство",
    }, 
    "regulatory-documents": {
        "ru": "Нормативные документы",
        "en": "Regulatory documents",
        "kz": "Нормативтік құжаттар",
    }, 
    "purchases": {
        "ru": "Закупки",
        "en": "Purchases",
        "kz": "Purchases",
    }, 
    "contacts": {
        "ru": "Контакты",
        "en": "Contacts",
        "kz": "Байланыс",
    }, 
    "search": {
        "ru": "Поиск",
        "en": "Regulatory documents",
        "kz": "Іздеу",
    }, 
}